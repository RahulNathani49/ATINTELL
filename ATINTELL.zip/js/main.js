var mytween = new TweenMax.to('#block', 1.5, {
    backgroundColor: 'red'
});
var controller = new ScrollMagic.Controller();
    var secondScene = new ScrollMagic.Scene({
        triggerElement: '.secondmain',
        triggerHook:0,
        duration: 500
    })
    .addIndicators()
    .setTween(mytween)
    .addTo(controller);